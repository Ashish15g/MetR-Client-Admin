# Markdown Example

Markdown is a lightweight markup language that you can use to add formatting elements to plaintext text documents. It's a popular choice for writing documentation, README files, and even for formatting messages in online forums.


* One 
    - Inner one
    - Ineer two
    - inner three with iamge
    ![hello](../images/abc.png)
* two 
    1. hello
    2. heiiii
    3. Javascript hello

* three 
    ![hello](../images/imagabce.png)
    - Inner one
    - Ineer two
        1. php
        2. java
            * nested of nested list
            * nested of nested list 2
            * nested of nested list 3
    - inner three with iamge



## Markdown is easy to learn and use

- **Simplicity**: Markdown is easy to learn and use. Its syntax is straightforward and intuitive.
- **Portability**: Markdown documents can be viewed in any text editor and easily converted to other formats like HTML or PDF.
- **Versatility**: Markdown supports a wide range of formatting options, including headers, lists, code blocks, and more.
- _**Widely Supported**_: Many platforms and tools support Markdown, making it a flexible choice for writing content.

[This is cross reference link example](./world/iron/defination.md)

### Markdown Code syntax

Here's an example of Markdown syntax:

```python
def greet(name):
    print("Hello, " + name + "!")
```

Markdown is a simple and easy plaintext [^1] language. It does not use any fancy [^2] commands.  
[^1]: Plaintext refers to the language that is not written in the encrypted form. It is easy to understand.  
[^2]: Fancy refers to the advance commands that makes the document more attractive.

