# Example with Emoji

This is a simple example of a DITA topic. This is a simple example of a DITA topic. This is a simple example of a DITA topic. This is a simple example of a DITA topic. This is a simple example of a DITA topic. This is a simple example of a DITA topic.

This is a subsection within the topic.

```
{
  "firstName": "John",
  "lastName": "Smith",
  "age": 25
}
```

| Product    | Price (USD) | Quantity |
| ---------- | ----------- | -------- |
| Laptop     | $800        | 10       |
| Smartphone | $600        | 20       |
| Tablet     | $400        | 15       |
| Headphones | $100        | 30       |
| Smartwatch | $300        | 25       |
| Camera     | $700        | 8        |
| Printer    | $200        | 12       |

At the command prompt, type `nano`

[hello](duckduckgo.com)

superscript^text^.

This is a sample sentence with subscript~text~.

\*[HTML]: Hyper Text Markup Language

## Hello from mars examples

Hello from mars :satellite:

==marked==

::: warning
_here be dragons_
:::

==very important words==

> Blockquotes **can** :satellite: also be nested...

Hello from mars :satellite: :smile:

Apple
: A fruit that grows on trees.

Banana
: A long curved fruit that grows in clusters.

Markdown
: A lightweight markup language with plain-text formatting syntax.
