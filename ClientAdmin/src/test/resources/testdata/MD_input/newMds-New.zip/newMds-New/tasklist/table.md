# table example

| Header 1 | Header 2 | Header 3 |
|----------|----------|----------|
| Row 1, Column 1 | Row 1, Column 2 | Row 1, Column 3 |
| Row 2, Column 1 | Row 2, Column 2 | Row 2, Column 3 |
| Row 3, Column 1 | Row 3, Column 2 | Row 3, Column 3 |
| Row 4, Column 1 | Row 4, Column 2 | Row 4, Column 3 |
| Row 5, Column 1 | Row 5, Column 2 | Row 5, Column 3 |
| Row 6, Column 1 | Row 6, Column 2 | Row 6, Column 3 |
| Row 7, Column 1 | Row 7, Column 2 | Row 7, Column 3 |
