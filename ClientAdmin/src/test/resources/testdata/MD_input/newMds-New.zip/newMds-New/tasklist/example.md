# Example task list

This is a simple example of a DITA topic. This is a simple example of a DITA topic. This is a simple example of a DITA topic. This is a simple example of a DITA topic. This is a simple example of a DITA topic. This is a simple example of a DITA topic.

This is a subsection within the topic.

- [ ] Finish the quarterly report
- [ ] Send emails to clients
- [ ] Prepare presentation for Monday meeting
- [ ] Update project management software


| Item   | Description    | hello | hi  | werwer                         |
| ------ | -------------- | ----- | --- | ------------------------------ |
| Apple  | A juicy fruit  | sds   | asd | sfsdfsdfsdfdsfd sdfsdfddfsdasd |
| Orange | A citrus fruit | sda   | asd | e234                           |
| Banana | A yellow fruit | we    | qwe |

[This is another cross reference link example](../Hello.md)

